<?php
	 Imprime os números de 1 a 20 um abaixo do outro
	for ($i = 1; $i <= 20; $i++) {
		echo $i . "<br>";
	}
?>

//<?php
	// Imprime os números de 1 a 20 um ao lado do outro
	//for ($i = 1; $i <= 20; $i++) {
		//echo $i . " ";
	//}
//?>