<?php
	// Imprime os números ímpares de 1 a 50
	for ($i = 1; $i <= 50; $i++) {
		if ($i % 2 != 0) {
			echo $i . " ";
		}
	}
?>